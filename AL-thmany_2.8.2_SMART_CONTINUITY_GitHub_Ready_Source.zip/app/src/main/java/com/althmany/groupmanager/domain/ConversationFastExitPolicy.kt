package com.althmany.groupmanager.domain

/**
 * Bounded timing policy for leaving a just-joined WhatsApp conversation.
 *
 * Fast mode still waits for one very small UI settle window before verifying the Back result.
 * A zero-delay verification can read the stale pre-Back tree on recent One UI builds and send an
 * unnecessary second Back. Two verified attempts are the maximum; continuity never loops.
 */
object ConversationFastExitPolicy {
    const val FAST_VERIFY_SETTLE_MS = 18L
    const val NORMAL_VERIFY_SETTLE_MS = 48L
    const val MAX_VERIFIED_BACK_ATTEMPTS = 2

    const val FAST_DIRECT_CONVERSATION_FALLBACK_AGE_MS = 520L
    const val NORMAL_DIRECT_CONVERSATION_FALLBACK_AGE_MS = 900L
    const val DIRECT_CONVERSATION_FALLBACK_STABLE_SCANS = 3

    fun settleMs(turbo: Boolean): Long =
        if (turbo) FAST_VERIFY_SETTLE_MS else NORMAL_VERIFY_SETTLE_MS

    fun directConversationFallbackAgeMs(turbo: Boolean): Long =
        if (turbo) FAST_DIRECT_CONVERSATION_FALLBACK_AGE_MS
        else NORMAL_DIRECT_CONVERSATION_FALLBACK_AGE_MS

    fun shouldTrustConversationWithoutWindowEvent(
        turbo: Boolean,
        stageAgeMs: Long,
        stableScreenScans: Int,
        loading: Boolean,
        inviteContext: Boolean
    ): Boolean =
        !loading &&
            !inviteContext &&
            stageAgeMs >= directConversationFallbackAgeMs(turbo) &&
            stableScreenScans >= DIRECT_CONVERSATION_FALLBACK_STABLE_SCANS

    fun shouldAttemptBack(turbo: Boolean, loading: Boolean, restricted: Boolean): Boolean {
        @Suppress("UNUSED_VARIABLE") val fast = turbo
        return !loading && !restricted
    }
}
